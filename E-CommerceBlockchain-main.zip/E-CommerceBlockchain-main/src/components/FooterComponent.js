import React from 'react';
import '../footer.css';
function FooterComponent() {

  return(
<>
	<div className="copyright ">
		<div className="container-fluid text-center">
					<p> 2023 - <a href="">Shop Blockchain</a>,  All Rights Reserved.<br></br>
					</p>

		</div>
	</div>


  </>
  );
}


export default FooterComponent;
